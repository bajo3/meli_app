/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['http2.mlstatic.com'], // dominio de las fotos de Mercado Libre
  },
};

module.exports = nextConfig;
